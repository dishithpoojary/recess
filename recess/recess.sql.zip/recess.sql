--
-- Database: `recess`
--

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `chatid` int(11) NOT NULL,
  `message` varchar(250) NOT NULL,
  `userid` int(11) NOT NULL,
  `communityid` int(11) NOT NULL,
  `time` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`chatid`, `message`, `userid`, `communityid`, `time`) VALUES
(1, 'hi boss', 2, 1, '05:36:11am'),
(2, 'hi wassup', 1, 1, '05:36:25am'),
(3, 'hello', 1, 1, '09:17:46am'),
(4, 'hi boss', 2, 1, '09:17:56am'),
(5, 'hi', 3, 3, '11:05:01am'),
(6, 'hello', 5, 3, '11:05:17am'),
(7, 'hi bitch', 3, 4, '11:53:47am'),
(8, 'i love you', 6, 4, '11:53:58am'),
(9, 'ok', 3, 4, '11:54:07am'),
(10, 'hi', 6, 5, '08:37:42am'),
(11, 'fo', 7, 5, '08:37:48am'),
(12, 'hi', 3, 6, '07:01:37am'),
(13, 'hi', 6, 8, '04:05:00am'),
(14, 'hi', 3, 3, '04:14:35am'),
(15, 'hi', 9, 9, '05:41:42am'),
(16, 'hi', 3, 9, '05:44:26am'),
(17, 'hi choco', 3, 10, '07:09:46am'),
(18, 'hello', 10, 10, '07:10:15am'),
(19, 'hi', 10, 11, '10:20:14am'),
(20, 'hi', 11, 11, '10:21:15am'),
(21, 'hi', 13, 12, '10:49:10am'),
(22, 'hello', 12, 12, '10:49:29am');

-- --------------------------------------------------------

--
-- Table structure for table `community`
--

CREATE TABLE `community` (
  `communityid` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `adminid` int(11) NOT NULL,
  `membercount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `community`
--

INSERT INTO `community` (`communityid`, `name`, `adminid`, `membercount`) VALUES
(1, 'dj comps', 1, 1),
(2, 'ok', 1, 1),
(3, 'fun', 5, 1),
(4, 'tp', 6, 1),
(5, 'choco', 7, 1),
(6, 'timepass', 6, 1),
(7, 'timepass', 3, 1),
(8, 'tp2', 3, 1),
(9, 'ok', 9, 1),
(10, 'Deepu', 10, 1),
(11, 'study', 11, 1),
(12, 'timepass', 12, 1);

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `memberid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `communityid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`memberid`, `userid`, `communityid`) VALUES
(1, 1, 1),
(2, 2, 1),
(4, 1, 2),
(5, 2, 2),
(6, 5, 3),
(7, 3, 3),
(8, 6, 4),
(9, 3, 4),
(10, 7, 5),
(11, 6, 5),
(12, 6, 4),
(13, 6, 6),
(14, 3, 6),
(15, 3, 7),
(16, 3, 7),
(17, 3, 8),
(18, 6, 8),
(19, 9, 9),
(20, 3, 9),
(21, 10, 10),
(22, 3, 10),
(23, 11, 11),
(24, 10, 11),
(25, 12, 12),
(26, 13, 12);

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `subjectid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `subjects` varchar(20) NOT NULL,
  `attendance` int(11) NOT NULL,
  `marks` int(11) NOT NULL,
  `assignments` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`subjectid`, `userid`, `subjects`, `attendance`, `marks`, `assignments`, `date`) VALUES
(1, 1, 'OS', 4, 12, 1, '2016-02-01'),
(2, 1, 'WT', 5, 12, 1, '2016-11-12'),
(3, 1, 'BCE', 11, 12, 0, '0000-00-00'),
(4, 1, 'SOOAD', 2, 12, 0, '0000-00-00'),
(5, 1, 'MP', 2, 12, 0, '0000-00-00'),
(6, 1, 'CN', 0, 18, 0, '0000-00-00'),
(7, 2, 'OS', 3, 0, 0, '0000-00-00'),
(8, 2, 'BCE', 10, 0, 0, '0000-00-00'),
(9, 2, 'WT', 4, 0, 0, '0000-00-00'),
(10, 3, 'WT', 3, 0, 12, '2016-11-11'),
(11, 3, 'BCE', 9, 0, 22, '2016-12-30'),
(12, 3, 'WER', 2, 0, 0, '0000-00-00'),
(13, 4, 'BCE', 9, 0, 0, '0000-00-00'),
(14, 4, 'OS', 2, 0, 0, '0000-00-00'),
(15, 4, 'WT', 3, 0, 0, '0000-00-00'),
(16, 5, 'WT', 3, 16, 2, '2016-11-04'),
(17, 5, 'BCE', 8, 17, 4, '2016-11-05'),
(18, 5, 'OS', 1, 19, 0, '0000-00-00'),
(19, 6, 'WT', 2, 13, 2, '2016-11-12'),
(20, 6, 'BCE', 7, 16, 0, '0000-00-00'),
(21, 6, 'OS', 1, 18, 0, '0000-00-00'),
(22, 7, 'BCE', 6, 18, 2, '2016-11-11'),
(23, 7, 'MP', 1, 18, 1, '2016-11-05'),
(24, 7, 'SOOA', 1, 19, 0, '0000-00-00'),
(25, 8, 'wt', 1, 0, 0, '0000-00-00'),
(26, 8, 'qwe', 0, 0, 0, '0000-00-00'),
(27, 8, 'bce', 3, 0, 0, '0000-00-00'),
(28, 9, 'bce', 3, 0, 0, '0000-00-00'),
(29, 9, 'wt', 1, 0, 0, '0000-00-00'),
(30, 9, 'toh', 0, 0, 0, '0000-00-00'),
(31, 10, 'bce', 3, 0, 1, '2016-12-15'),
(32, 10, 'cg', 1, 0, 0, '0000-00-00'),
(33, 10, 'wt', 1, 0, 0, '0000-00-00'),
(34, 10, 'oopm', 0, 0, 0, '0000-00-00'),
(35, 11, 'BCE', 2, 20, 1, '2015-12-14'),
(36, 11, 'GDGD', 2, 0, 0, '0000-00-00'),
(37, 11, 'WT', 1, 0, 0, '0000-00-00'),
(38, 12, 'math', 0, 0, 0, '0000-00-00'),
(39, 13, 'maths', 0, 0, 0, '0000-00-00'),
(40, 13, 'ss', 0, 0, 0, '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `todo`
--

CREATE TABLE `todo` (
  `todoid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `item` varchar(200) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `todo`
--

INSERT INTO `todo` (`todoid`, `userid`, `item`, `date`) VALUES
(1, 1, 'study for mp', '2016-11-10'),
(2, 1, 'complete xyz', '2016-11-05'),
(3, 1, 'i have exams', '2016-12-12'),
(4, 1, 'xeer', '2016-11-01'),
(5, 6, 'dance', '2016-11-03'),
(6, 7, 'complete xyz', '2016-11-12'),
(7, 10, 'seminar', '0216-12-15'),
(8, 11, 'complete assignment xyx', '2016-12-15');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(30) NOT NULL,
  `img` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `name`, `email`, `username`, `password`, `dob`, `gender`, `img`) VALUES
(1, 'dishith poojary', 'dishithpoojary@ymail.com', 'dishith', '123456', '1996-09-10', 'M', 'user.jpg'),
(2, 'dhunvi rai', 'drai@gmail.com', 'dhunvi', '123456', '1996-03-05', 'F', 'user.jpg'),
(3, 'dishith poojary', 'dishithpoojary@gmail.com', 'dishi', '123456', '1111-11-11', 'F', 'c1.png'),
(4, 'YAsh vora', 'yashnirali@gmail.com', 'yash', '123456', '0199-12-10', 'M', 'user.jpg'),
(5, 'sudhir bagul', 'sudhirbagul@gmail.com', 'sudhir', '123456', '1997-11-11', 'M', 'user.jpg'),
(6, 'sanchi shah', 'sa@gmail.com', 'sanchi', '123456', '2016-11-18', 'F', 'user.jpg'),
(7, 'nishith sakariya', 'nshit@gmail.com', 'nishit', '123456', '1996-09-19', 'M', 'user.jpg'),
(8, 'ketaki shah', 'kk@gmail.com', 'ketaki', '12345', '2111-11-11', 'F', 'user.jpg'),
(9, 'ketaki shah', 'kk@gmail.com', 'ketaki1', '123456', '0000-00-00', 'F', 'c2.png'),
(10, 'akshay shah', 'ans@gmail.com', 'akshay', '123456', '1111-11-11', 'M', 'c3.png'),
(11, 'deepak mangali', 'DD@GMAIL.COM', 'deepK', '12345', '1877-11-11', 'M', 'c1.png'),
(12, 'zeel', 'zeel@gmail.com', 'zeel', 'pass@123', '0000-00-00', 'F', 'csi week  certis.jpg'),
(13, 'chahat', 'chahat@gmail.com', 'chah', 'pass@123', '1111-11-11', 'M', 'double exposure.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`chatid`);

--
-- Indexes for table `community`
--
ALTER TABLE `community`
  ADD PRIMARY KEY (`communityid`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`memberid`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`subjectid`);

--
-- Indexes for table `todo`
--
ALTER TABLE `todo`
  ADD PRIMARY KEY (`todoid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `chatid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `community`
--
ALTER TABLE `community`
  MODIFY `communityid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `memberid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `subjectid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `todo`
--
ALTER TABLE `todo`
  MODIFY `todoid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
